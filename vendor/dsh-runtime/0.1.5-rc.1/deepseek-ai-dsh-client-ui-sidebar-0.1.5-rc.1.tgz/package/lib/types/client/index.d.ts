/** Sidebar contracts; the workbench declares and renders the visual seats. */
export type { SidebarBrandMarkOwnerProps, SidebarBrandNameOwnerProps, SidebarFooterActionOwnerProps, SidebarPanelIconOwnerProps, SidebarPanelMetadata, SidebarSectionOwnerProps, SidebarSettingsOwnerProps, } from './contract/slots.ts';
/** No browser services or visual registrations are owned by this contract entry. */
export declare const inject: never[];
/** Retain the Loader entry without mounting a sidebar. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map