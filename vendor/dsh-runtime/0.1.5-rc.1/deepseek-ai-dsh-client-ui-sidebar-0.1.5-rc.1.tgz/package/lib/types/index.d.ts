/** Host loader entry for the browser-only ui-sidebar package. */
/** Provides no host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map