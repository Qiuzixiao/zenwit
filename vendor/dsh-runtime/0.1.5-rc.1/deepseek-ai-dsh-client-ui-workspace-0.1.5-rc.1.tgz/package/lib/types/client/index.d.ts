/** Workspace navigation service and root-scoped Workspace snapshot adapter. */
import type { Context } from '@deepseek-ai/cordis';
import type { WorkspaceSnapshot } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
export type { UiWorkspace, WorkspacePendingAction } from './navigation.ts';
export type { DirectoryFlowOwnerProps, DirectoryFlowSlotName } from './contract/slots.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface GlobalStandardProps {
        /** Selector hook over the pure Workspace Controller snapshot. */
        useWorkspaces: SnapshotSelectorHook<WorkspaceSnapshot>;
    }
}
/** Services required by navigation and the Workspace snapshot adapter. */
export declare const inject: string[];
/**
 * Provide Workspace navigation and hooks; visual seats belong to the workbench.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map