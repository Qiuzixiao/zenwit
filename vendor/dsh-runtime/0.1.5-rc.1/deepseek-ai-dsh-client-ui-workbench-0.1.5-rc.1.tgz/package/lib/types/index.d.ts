/** Host loader entry for the browser workbench. */
/** Browser-only plugin; the host mounts its file API separately. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map