/**
 * Lazy chunk loader for the workbench's heavy views.
 *
 * The editor (CodeMirror), terminal (xterm) and diagram (mermaid) stacks are
 * several megabytes; each lives behind a `chunks/<name>.tsx` re-export shim
 * so the view module loads only on first use of the feature that needs it.
 * The kernel bundles one dynamic client artifact per package, so these loads
 * are the bundler's own `import()` rather than a plugin-served chunk script;
 * the loader API (name in, module exports out, one in-flight promise per
 * chunk) is what the views depend on.
 *
 * Test seams: {@link registerChunkForTests} substitutes a loader for one
 * name, and {@link setChunkScriptLoaderForTests} stays as a no-op for older
 * callers.
 */
export type ChunkName = 'terminal' | 'editor' | 'mermaid';
/** The module exports a chunk provides (namespace-ish record). */
export type ChunkExports = Record<string, unknown>;
/**
 * Platform modules the chunk sources reach: React and the shared UI
 * libraries the kernel's client baseline seeds for every dynamic bundle.
 */
export declare const CHUNK_EXTERNALS: readonly string[];
/** The client module system surface callers used to inject (kept for API compatibility). */
export interface ChunkModuleSystem {
    import(specifier: string): Promise<unknown>;
}
/**
 * Accept the client module system. The bundled build resolves its externals
 * itself, so the value is not read; the call keeps the activation sequence
 * identical for callers that still pass it.
 * @param system - the module system, or undefined to clear.
 */
export declare function setChunkModuleSystem(system: ChunkModuleSystem | undefined): void;
/**
 * No-op revalidation hook: a bundled chunk is re-imported with the bundle
 * that owns it, so there is no chunk script to revalidate on re-activation.
 * @returns a resolved promise.
 */
export declare function revalidateChunksOnReactivate(): Promise<void>;
/**
 * Install a test loader for one chunk name.
 * @param name - the chunk to override.
 * @param loader - the replacement loader.
 */
export declare function registerChunkForTests(name: ChunkName, loader: () => Promise<ChunkExports>): void;
/**
 * Accept a legacy script loader override; the bundled build ignores it.
 * @param loader - the override, or null to clear.
 */
export declare function setChunkScriptLoaderForTests(loader: (() => Promise<void>) | null): void;
/**
 * Load one chunk, at most once per name.
 * @param name - the chunk to load.
 * @returns the chunk's exports.
 */
export declare function loadChunk(name: ChunkName): Promise<ChunkExports>;
/** Drop all chunk state (a fresh activation re-imports lazily). */
export declare function resetChunks(): void;
//# sourceMappingURL=chunk-loader.d.ts.map