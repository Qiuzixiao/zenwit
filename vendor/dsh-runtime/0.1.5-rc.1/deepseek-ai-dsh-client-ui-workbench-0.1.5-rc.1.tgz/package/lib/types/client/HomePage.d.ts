import type { CopyProps } from './contract.ts';
import type { ProjectSummary } from './project-api.ts';
/** Home page: project search, filtering, creation and selected-project actions. */
export declare function HomePage({ list, create, updateProjectTags, deleteProject, forgetProject, openProject, openLibrary, openFolder, t, ready, }: {
    list: () => Promise<ProjectSummary[]>;
    create: (name: string, tags: string[]) => Promise<ProjectSummary>;
    updateProjectTags: (projectPath: string, tags: string[]) => Promise<ProjectSummary>;
    deleteProject: (projectPath: string) => Promise<void>;
    forgetProject: (projectPath: string) => Promise<void>;
    openProject: (projectPath: string) => Promise<void>;
    openLibrary: () => void;
    openFolder: () => void;
    t: CopyProps['t'];
    ready?: boolean;
}): import("react").JSX.Element;
//# sourceMappingURL=HomePage.d.ts.map