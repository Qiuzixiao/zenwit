import type { CopyProps, Panel, WorkbenchProps } from './contract.ts';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { ProjectSummary } from './project-api.ts';
/** Home surface props: project data, the panel entries it navigates to, and slot rendering. */
export interface HomePageProps extends CopyProps {
    list: () => Promise<ProjectSummary[]>;
    create: (name: string, tags: string[]) => Promise<ProjectSummary>;
    updateProjectTags: (projectPath: string, tags: string[]) => Promise<ProjectSummary>;
    deleteProject: (projectPath: string) => Promise<void>;
    forgetProject: (projectPath: string) => Promise<void>;
    openProject: (projectPath: string) => Promise<void>;
    openLibrary: () => void;
    openFolder: () => void;
    /** Return to the home surface from the chrome's own navigation. */
    goHome: () => void;
    /** Registered main-panel entries offered beside the built-in surfaces. */
    panels: readonly Panel[];
    /** Main panel hosting this surface, or null while a built-in surface owns it. */
    activePanel: MainPanelId | null;
    /** Select a main panel, or null to return to the built-in surfaces. */
    selectPanel: (id: MainPanelId | null) => void;
    renderSlot: WorkbenchProps['renderSlot'];
    ready?: boolean;
}
/** Home page: project search, filtering, creation and selected-project actions. */
export declare function HomePage({ list, create, updateProjectTags, deleteProject, forgetProject, openProject, openLibrary, openFolder, goHome, panels, activePanel, selectPanel, renderSlot, t, ready, }: HomePageProps): import("react").JSX.Element;
//# sourceMappingURL=HomePage.d.ts.map