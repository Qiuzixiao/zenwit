/** Workbench chrome shared by every built-in first-level surface. */
import type { ReactNode } from 'react';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { CopyProps, Panel, WorkbenchProps } from './contract.ts';
/** Built-in surface the chrome is currently rendered for. */
export type WorkbenchSurface = 'home' | 'library';
/** Chrome props: the live panel registry, the selection, and the surface actions. */
export interface WorkbenchTopBarProps extends CopyProps {
    surface: WorkbenchSurface;
    panels: readonly Panel[];
    activePanel: MainPanelId | null;
    selectPanel: (id: MainPanelId | null) => void;
    goHome: () => void;
    openLibrary: () => void;
    renderSlot: WorkbenchProps['renderSlot'];
    /** Surface-owned tools rendered after the settings seat. */
    children?: ReactNode;
}
/**
 * Render the brand block, the first-level navigation and the settings seat.
 *
 * Both built-in surfaces render this component so their chrome cannot drift
 * apart; only the tool cluster on the right belongs to the surface.
 */
export declare function WorkbenchTopBar({ surface, panels, activePanel, selectPanel, goHome, openLibrary, renderSlot, t, children, }: WorkbenchTopBarProps): import("react").JSX.Element;
//# sourceMappingURL=WorkbenchTopBar.d.ts.map