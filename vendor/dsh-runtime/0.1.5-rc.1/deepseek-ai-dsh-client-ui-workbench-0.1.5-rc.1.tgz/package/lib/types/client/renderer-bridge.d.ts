import type { CopyProps } from './contract.ts';
import type { DocumentRenderers } from './document-renderers.ts';
import type { FileViewerProps } from './workbench/service.ts';
/** The engine viewer-registration face this adapter needs. */
export interface EngineViewerRegistry {
    registerFileViewer(descriptor: {
        id: string;
        title: string;
        exts: readonly string[];
        priority?: number;
        fetchStrategy: 'fsRead';
        component: (props: FileViewerProps) => React.ReactNode;
    }): () => void;
}
/**
 * Mirror every accepted document renderer into the engine's viewer registry
 * and keep the two in step while registrations come and go.
 * @param registry - the public document-renderer registry.
 * @param engine - the engine's viewer registration face.
 * @param t - the workbench copy seat handed to bridged views.
 * @returns a disposer removing every bridged viewer.
 */
export declare function bridgeDocumentRenderers(registry: DocumentRenderers, engine: EngineViewerRegistry, t: CopyProps['t']): () => void;
//# sourceMappingURL=renderer-bridge.d.ts.map