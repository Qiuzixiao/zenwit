/** Filesystem paths and persistent document-tab metadata, separate from shell rendering. */
export declare const DOCUMENT_TABS_STORAGE_PREFIX = "zenwit.document-tabs.";
/** One real tree node: a directory or file under the project root. */
export interface TreeNode {
    name: string;
    path: string;
    kind: 'file' | 'dir';
    /** Word count for .md files, byte size for others, '' for directories. */
    detail: string;
    children?: TreeNode[];
}
export interface StructureResponse {
    path: string;
    tree: TreeNode[];
    root: string;
}
export interface OpenDocument {
    path: string;
    name: string;
    content: string;
    draft: string;
    dirty: boolean;
    saving: boolean;
    saveStatus: string | null;
    visualMode: boolean;
    externalUpdate?: {
        content: string;
    } | undefined;
    conflict?: {
        content: string | null;
    } | undefined;
    syncError?: string | undefined;
}
export interface PersistedDocumentTabs {
    activePath: string | null;
    documents: Array<Pick<OpenDocument, 'path' | 'name' | 'visualMode'>>;
}
export declare function nodePath(parent: string, name: string): string;
export declare function nodeBasename(path: string): string;
export declare function descendantSuffix(path: string, parent: string): string | null;
/** Accept only a file lexically below the active project root. */
export declare function isProjectFilePath(path: string, projectPath: string): boolean;
export declare function readPersistedTabs(projectPath: string): PersistedDocumentTabs | null;
export declare function flattenFiles(nodes: TreeNode[]): TreeNode[];
export declare function filterTree(nodes: TreeNode[], query: string): TreeNode[];
/**
 * Normalize a chat file target, rejecting remote URLs and traversal outside the project.
 * @param url - path or local file URL.
 * @param projectPath - current project directory.
 * @returns absolute path beneath the current project.
 */
export declare function resolveFilePath(url: string, projectPath: string | undefined): string;
//# sourceMappingURL=workspace-files.d.ts.map