/** Filesystem paths and persistent document-tab metadata, separate from shell rendering. */
export declare const DOCUMENT_TABS_STORAGE_PREFIX = "zenwit.document-tabs.";
/** One real tree node: a directory or file under the project root. */
export interface TreeNode {
    name: string;
    path: string;
    kind: 'file' | 'dir';
    /** Word count for .md files, byte size for others, '' for directories. */
    detail: string;
    children?: TreeNode[];
}
/** The active project's file tree and its root directory. */
export interface StructureResponse {
    path: string;
    tree: TreeNode[];
    root: string;
    /** True when the host entry budget cut the tree short; absent on hosts that do not bound scans. */
    truncated?: boolean;
}
/** One open editor tab: disk content, the live draft, and its save or conflict state. */
export interface OpenDocument {
    path: string;
    name: string;
    /** Text encoding the file is stored in; echoed back on save so it is preserved. */
    encoding: string;
    content: string;
    draft: string;
    dirty: boolean;
    saving: boolean;
    saveStatus: string | null;
    visualMode: boolean;
    externalUpdate?: {
        content: string;
    } | undefined;
    conflict?: {
        content: string | null;
    } | undefined;
    syncError?: string | undefined;
}
/** Tab metadata persisted per project so reopened tabs survive a reload. */
export interface PersistedDocumentTabs {
    activePath: string | null;
    documents: Array<Pick<OpenDocument, 'path' | 'name' | 'visualMode'>>;
}
/**
 * Join a file-manager node name onto its parent with the parent's separator.
 * @param parent - parent directory path.
 * @param name - child name.
 * @returns the joined path.
 */
export declare function nodePath(parent: string, name: string): string;
/**
 * Take the final segment of a POSIX or Windows path.
 * @param path - the path to split.
 * @returns the final segment, or an empty string when none exists.
 */
export declare function nodeBasename(path: string): string;
/**
 * Return the path suffix below a parent, or null when the path is not a descendant.
 * @param path - candidate absolute path.
 * @param parent - ancestor directory.
 * @returns the suffix including its leading separator, or null.
 */
export declare function descendantSuffix(path: string, parent: string): string | null;
/**
 * Accept only a file lexically below the active project root.
 * @param path - candidate absolute path.
 * @param projectPath - active project directory.
 * @returns whether the path stays inside the project without a `..` segment.
 */
export declare function isProjectFilePath(path: string, projectPath: string): boolean;
/**
 * Read the persisted tab metadata for one project.
 * @param projectPath - active project directory.
 * @returns valid persisted tabs, or null when absent or malformed.
 */
export declare function readPersistedTabs(projectPath: string): PersistedDocumentTabs | null;
/**
 * Flatten a project tree to its file nodes in traversal order.
 * @param nodes - tree nodes to walk.
 * @returns every descendant file node.
 */
export declare function flattenFiles(nodes: TreeNode[]): TreeNode[];
/**
 * Keep tree nodes whose path matches, preserving matching ancestors.
 * @param nodes - tree nodes to filter.
 * @param query - case-insensitive path substring; empty keeps everything.
 * @returns the filtered tree.
 */
export declare function filterTree(nodes: TreeNode[], query: string): TreeNode[];
/**
 * Normalize a chat file target, rejecting remote URLs and traversal outside the project.
 * @param url - path or local file URL.
 * @param projectPath - current project directory.
 * @returns absolute path beneath the current project.
 */
export declare function resolveFilePath(url: string, projectPath: string | undefined): string;
//# sourceMappingURL=workspace-files.d.ts.map