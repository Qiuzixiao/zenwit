import type { Context } from './workbench-context.ts';
import { type WorkbenchStore } from './workbench-store.ts';
/** Open a file in the workbench's editor (used by the intercepted row and the explorer). */
export declare function openWorkbenchFile(ctx: Context, _store: WorkbenchStore, sessionId: string, path: string): void;
/**
 * Reveal the produced files in the explorer column: expand their parent
 * directories and highlight the rows (the column is always on screen in the
 * workspace, so nothing has to be opened). Unknown files fall back to
 * revealing the workspace root itself.
 */
export declare function revealInExplorer(ctx: Context, store: WorkbenchStore, sessionId: string, files: readonly string[]): void;
/** The intercepted produced-files row (visual twin of the deliverables chips). */
export declare function WorkbenchProducedFiles(props: {
    matched: readonly string[];
    openInWorkbench: (path: string) => void;
    /** Reveal the produced files in the explorer ("Show in folder" twin). */
    onShowInFolder: (files: readonly string[]) => void;
}): import("react").JSX.Element;
/**
 * Register the turn-tail interception (returns the disposer).
 *
 * The slot is a CHILD slot the host's ui-conversation declares in its
 * `conversation.chat.node` children table (kind: chain, scope: session).
 * Registering it directly races the declaration — the ui-slots core's
 * load-time validation throws "not declared (a parent entry's children
 * table must declare it)" when the parent entry is not on the ledger yet.
 * slots.inject waits for the declaration: the callback runs synchronously
 * when the slot is already declared, otherwise it runs inside the declaring
 * register() call once the declaration commits; declaration collapse
 * disposes the entry and a later declaration re-registers it. This mirrors
 * @deepseek-ai/dsh-client-ui-deliverables' registration of the same slot.
 */
export declare function registerTurnTailInterception(ctx: Context, store: WorkbenchStore): () => void;
//# sourceMappingURL=intercept.d.ts.map