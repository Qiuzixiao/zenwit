import type { Context } from './workbench-context.ts';
import type { SessionScope } from './api.ts';
import type { WorkbenchTab } from './state.ts';
/** The thread a tab is bound to (durable in tab.meta across refreshes). */
export declare function sidechatThreadIdOf(tab: WorkbenchTab): string | undefined;
/** Park a thread id for the NEXT sidechat openTab to reattach. */
export declare function parkSidechatReopen(threadId: string): void;
/** Consume the parked reopen target (undefined = mint a fresh thread tab). */
export declare function consumeSidechatSeed(): string | undefined;
/** One side conversation tab (one thread per tab, Codex-style). */
export declare function SideChatView(props: {
    ctx: Context;
    scope: SessionScope;
    tab: WorkbenchTab;
    visible: boolean;
}): React.ReactNode;
//# sourceMappingURL=SideChatView.d.ts.map