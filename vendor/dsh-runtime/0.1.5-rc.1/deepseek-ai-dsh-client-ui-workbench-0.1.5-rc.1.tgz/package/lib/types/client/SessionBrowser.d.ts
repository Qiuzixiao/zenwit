import type { WorkbenchProps } from './contract.ts';
type Props = Pick<WorkbenchProps, 't' | 'useSessions' | 'useWorkspaces' | 'useSessionPendingInteraction' | 'usePendingActions' | 'openSession' | 'searchSessions' | 'renameSession' | 'archiveSession' | 'forkSession'> & {
    mode: 'history' | 'pending';
    projectPath?: string | undefined;
    onClose(): void;
};
/** History and attention share session identities, while actions stay with their owners. */
export declare function SessionBrowser(props: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=SessionBrowser.d.ts.map