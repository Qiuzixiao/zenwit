export declare function OpenWithSettings(props: {
    pluginSettings: Record<string, unknown>;
    updatePluginSetting: (key: string, value: unknown) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=open-with-settings.d.ts.map