/** Browser requests for the host-owned generic project and file API. */
/** Project-library row; no agent or domain metadata is needed by this UI. */
export interface ProjectSummary {
    name: string;
    path: string;
    tags: string[];
    updatedAt: number;
    canDelete?: boolean;
    available?: boolean;
}
/** Explicit API callbacks injected into the presentation layer. */
export declare const projectApi: {
    list(signal?: AbortSignal): Promise<ProjectSummary[]>;
    create(name: string, tags: string[]): Promise<ProjectSummary>;
    updateTags(path: string, tags: string[]): Promise<ProjectSummary>;
    remove(path: string): Promise<void>;
    forget(path: string): Promise<void>;
    adopt(path: string): Promise<ProjectSummary>;
};
/** Injected file and project commands. */
export type ProjectApi = typeof projectApi;
//# sourceMappingURL=project-api.d.ts.map