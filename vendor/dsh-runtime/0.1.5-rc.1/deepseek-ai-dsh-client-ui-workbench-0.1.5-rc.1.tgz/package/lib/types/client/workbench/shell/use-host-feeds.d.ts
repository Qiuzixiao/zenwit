import type { Context, WorkbenchSessionList } from '../workbench-context.ts';
import type { WorkbenchStore } from '../workbench-store.ts';
export declare function useHostFeeds(feeds: {
    ctx: Context;
    store: WorkbenchStore;
    sessionList: WorkbenchSessionList;
    sessionId: string | undefined;
}): {
    subagentJumpRef: {
        current: string | undefined;
    };
};
//# sourceMappingURL=use-host-feeds.d.ts.map