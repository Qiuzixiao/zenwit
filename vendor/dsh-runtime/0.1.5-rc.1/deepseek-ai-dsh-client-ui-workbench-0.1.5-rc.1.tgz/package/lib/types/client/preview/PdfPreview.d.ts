import type { CopyProps } from '../contract.ts';
/** @param props - complete PDF bytes and workbench copy. @returns a scrolling PDF reader. */
export declare function PdfPreview({ data, t }: {
    data: Uint8Array<ArrayBuffer>;
} & CopyProps): import("react").JSX.Element;
//# sourceMappingURL=PdfPreview.d.ts.map