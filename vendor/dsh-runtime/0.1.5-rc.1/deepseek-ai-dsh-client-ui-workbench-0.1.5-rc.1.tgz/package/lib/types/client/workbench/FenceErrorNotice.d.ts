import type { WorkbenchStore } from './workbench-store.ts';
export declare function FenceErrorNotice(props: {
    store: WorkbenchStore;
    onDisabled: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=FenceErrorNotice.d.ts.map