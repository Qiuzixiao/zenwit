/** Workbench capability layer over the renderer registry: offered views and the built-in editor. */
import type { DocumentDescriptor, DocumentViewId, RendererFallbackReason } from './document-descriptor.ts';
import type { DocumentRenderers } from './document-renderers.ts';
/** The built-in editor the Workbench renders when no renderer supplies the preview view. */
export type WorkbenchEditor = 'markdown' | 'text';
/** One document as the Workbench presents it. */
export interface WorkbenchDocument {
    /** The registry's authoritative descriptor. */
    readonly descriptor: DocumentDescriptor;
    /** Ordered offered views, including the built-in markdown preview when it applies. */
    readonly views: readonly DocumentViewId[];
    /** Built-in editor for text storage; undefined for binary storage. */
    readonly editor: WorkbenchEditor | undefined;
    /** Whether a preview view is offered. */
    readonly hasPreview: boolean;
    /** Whether preview and source can be switched, which is what enables the toolbar toggle. */
    readonly canSwitchViews: boolean;
    /** Why no renderer backs the preview view, when the descriptor has none. */
    readonly fallback: RendererFallbackReason | undefined;
}
/**
 * Derive how the Workbench presents one file: the registry descriptor plus the
 * built-in editor view. Markdown's visual editor is a Workbench editor, not a
 * renderer, so it is added here when no renderer supplies the preview view.
 * @param renderers - the document renderer registry.
 * @param path - the file path.
 * @param size - known byte size, or `undefined` when unknown.
 * @returns the descriptor, offered views, editor and toggle capability.
 */
export declare function describeWorkbenchDocument(renderers: DocumentRenderers, path: string, size?: number): WorkbenchDocument;
/**
 * Pick the view to render for a document.
 * @param views - offered views in canonical order.
 * @param visualMode - the document's persisted preview preference.
 * @returns the selected view id, or `undefined` when the document offers no view.
 */
export declare function selectedView(views: readonly DocumentViewId[], visualMode: boolean): DocumentViewId | undefined;
//# sourceMappingURL=document-capabilities.d.ts.map