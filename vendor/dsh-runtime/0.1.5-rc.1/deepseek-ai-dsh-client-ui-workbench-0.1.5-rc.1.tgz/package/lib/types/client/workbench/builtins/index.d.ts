/**
 * Built-in registration: the plugin registers its own tab pages and file
 * previewers through the same {@link WorkbenchEngineService} external plugins
 * use — eating its own dogfood. The descriptors live next to their feature
 * modules (tabs.tsx / viewers.tsx); this module only aggregates them and
 * owns the disposer lifecycle (cordis auto-invokes it on fiber disposal,
 * HMR-safe).
 */
import type { Context } from '../workbench-context.ts';
import type { WorkbenchEngineService } from '../service.ts';
import { type BuiltinTabOptions } from './tabs.tsx';
/**
 * Register all built-in tabs and viewers with the service. Returns a
 * disposer that unregisters everything (cordis auto-invokes it on fiber
 * disposal). The `ctx` is threaded into tab descriptors that need it
 * (EditorHost reads `ctx.workbenchEngine` for file-viewer matching).
 */
export declare function registerBuiltins(ctx: Context, service: WorkbenchEngineService, options?: BuiltinTabOptions): () => void;
//# sourceMappingURL=index.d.ts.map