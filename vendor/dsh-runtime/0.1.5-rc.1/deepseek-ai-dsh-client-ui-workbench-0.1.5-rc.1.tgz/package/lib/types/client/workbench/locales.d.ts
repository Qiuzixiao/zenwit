/**
 * Minimal zh/en/ja copy for the workbench. The copy follows the DSH i18n system:
 * the client apply attaches the locale service (`ctx.locale`, provided by
 * `@deepseek-ai/dsh-client-locale`) through {@link attachLocale}, and
 * `t()`/`isZh()` resolve the active locale from it — the Host-backed
 * `locale.preference` wins over the raw browser language and switches live.
 * Without an attached service (standalone/test compositions) the browser
 * language is used, matching the previous behavior. The dictionaries are
 * also registered into the DSH locale registry under {@link LOCALE_NS}.
 *
 * ja (Japanese) is opt-in through `@huanlin/dsh-plugin-better-locale`: when
 * that plugin is installed, the client apply also calls
 * {@link attachBetterLocale} with the override store. `t()` then consults
 * the store's active override id first; if it is `'ja'` (or any id whose
 * dict has the requested key) the ja text wins, otherwise the existing
 * zh/en chain runs unchanged. better-locale itself patches
 * `LocaleRuntime.prototype.lookup` so DSH's own translate chain also
 * returns ja where the `workbenchEngine` namespace has a ja entry — that
 * path covers external callers of `ctx.locale.bind('workbenchEngine')`,
 * while the override-aware `t()` here covers zenwit-workbench's own
 * components (which bypass `ctx.locale` and call `t()` directly).
 */
/** The zh dictionary (also registered into the DSH locale registry under {@link LOCALE_NS}). */
export declare const zh: {
    files: string;
    start: string;
    guideDescFiles: string;
    guideDescGit: string;
    guideDescSubagent: string;
    guideDescSidechat: string;
    guideDescTerminal: string;
    guideDescBrowser: string;
    changesSessionEmpty: string;
    changesRead: string;
    changesMdReading: string;
    changesMdRaw: string;
    changesHtmlRender: string;
    changesHtmlRaw: string;
    changesPdfRender: string;
    changesPdfRaw: string;
    changesWrite: string;
    changesEdit: string;
    changesRunning: string;
    changesError: string;
    changesRedactOn: string;
    changesRedactOff: string;
    changesRedactOnLabel: string;
    changesRedactOffLabel: string;
    changesRedactBanner: string;
    changesFold: string;
    changesFoldLoading: string;
    changesFoldUnavailable: string;
    changesContext: string;
    changesPriorUnknown: string;
    explorer: string;
    terminal: string;
    editor: string;
    editorTreeToggle: string;
    editorPathPlaceholder: string;
    editorSearchPlaceholder: string;
    editorSearchNoResults: string;
    editorSearchTruncated: string;
    editorEmptyHint: string;
    chunkMissing: string;
    versionTag: string;
    saveShortcut: string;
    sidechatUnavailable: string;
    openFileNewTab: string;
    openFileSide: string;
    openWithMenu: string;
    openWithSshSuffix: string;
    pinOpenWith: string;
    unpinOpenWith: string;
    openWithExplorer: string;
    openWithVscode: string;
    openWithCursor: string;
    openWithZed: string;
    openWithSettingsSshTitle: string;
    openWithSettingsSshDesc: string;
    openWithSettingsSshPlaceholder: string;
    openWithSettingsCustomTitle: string;
    openWithSettingsCustomDesc: string;
    openWithSettingsAdd: string;
    openWithSettingsName: string;
    openWithSettingsTemplate: string;
    openWithSettingsFamily: string;
    openWithSettingsFamilyDesc: string;
    openWithSettingsRemove: string;
    openWithSettingsInvalidHint: string;
    newTab: string;
    openExplorer: string;
    brokenSymlink: string;
    openGit: string;
    newTerminal: string;
    terminalLimit: string;
    close: string;
    closeOtherTabs: string;
    closeLeftTabs: string;
    closeRightTabs: string;
    floatDropHint: string;
    dockToWorkbench: string;
    pinTerminal: string;
    pinToWorkspace: string;
    pinToGlobal: string;
    unpinTerminal: string;
    pinnedTerminalTooltip: string;
    pinnedTerminalKindUi: string;
    pinnedTerminalScopeWorkspace: string;
    pinnedTerminalScopeGlobal: string;
    pinnedRailLabel: string;
    closePinnedTerminal: string;
    terminalError: string;
    terminalConnectFailed: string;
    terminalRetry: string;
    terminalDepsFailed: string;
    terminalDepsHint: string;
    terminalDepsProfile: string;
    terminalShellNotFound: string;
    preview: string;
    toc: string;
    edit: string;
    mermaidError: string;
    mermaidZoomIn: string;
    mermaidZoomOut: string;
    mermaidZoomReset: string;
    mermaidZoomHint: string;
    refresh: string;
    refreshUnsavedConfirm: string;
    save: string;
    saved: string;
    unsaved: string;
    saveFailed: string;
    truncation: string;
    binary: string;
    loading: string;
    error: string;
    retry: string;
    splitLeft: string;
    splitRight: string;
    splitUp: string;
    splitDown: string;
    notRepo: string;
    noChanges: string;
    statusTruncated: string;
    stage: string;
    unstage: string;
    stageAll: string;
    unstageAll: string;
    commitPlaceholder: string;
    commit: string;
    commitError: string;
    branch: string;
    worktree: string;
    checkoutError: string;
    history: string;
    changes: string;
    changesGitLens: string;
    changesSessionLens: string;
    changesFilterAll: string;
    changesFilterEmpty: string;
    changesOpenDiffTab: string;
    changesClosePreview: string;
    changesResizePreview: string;
    changesLoadError: string;
    staged: string;
    unstaged: string;
    cancel: string;
    diffEmpty: string;
    diffLoadError: string;
    diffBinary: string;
    diffAdded: string;
    diffDeleted: string;
    diffRenamed: string;
    diffExpand: string;
    diffCollapse: string;
    discard: string;
    discardTitle: string;
    discardDesc: string;
    viewCommitDiff: string;
    copyShortHash: string;
    copyFullHash: string;
    copySubject: string;
    revertCommit: string;
    revertTitle: string;
    revertDesc: string;
    cherryPickCommit: string;
    cherryPickTitle: string;
    cherryPickDesc: string;
    timeJustNow: string;
    timeMinutesAgo: string;
    timeHoursAgo: string;
    timeYesterday: string;
    loadMore: string;
    historyLoadError: string;
    produced: string;
    producedOpen: string;
    showInFolder: string;
    disconnected: string;
    exited: string;
    noSession: string;
    pluginNotLoaded: string;
    hiddenFiles: string;
    parent: string;
    copied: string;
    copy: string;
    newFile: string;
    openEditor: string;
    gitDetail: string;
    referenceFile: string;
    addToConversation: string;
    copyRelative: string;
    copyAbsolute: string;
    rename: string;
    renameInvalid: string;
    delete: string;
    deleteTitle: string;
    deleteDescFile: string;
    deleteDescDir: string;
    dismiss: string;
    download: string;
    uploadFiles: string;
    uploadFolder: string;
    uploadHere: string;
    uploadDropHint: string;
    uploadDropChat: string;
    uploadTo: string;
    uploadingTo: string;
    uploadProgress: string;
    uploadDone: string;
    uploadFailed: string;
    uploadFailedUnknown: string;
    uploadTooLarge: string;
    uploadCancelled: string;
    settingsNav: string;
    settingsProductName: string;
    settingsIntro: string;
    settingsPopupDesc: string;
    settingsDone: string;
    settingsOpenToolsTitle: string;
    settingsOpenToolsDesc: string;
    settingsSaveFailed: string;
    settingsConflict: string;
    binaryNoPreview: string;
    downloadToView: string;
    settingsSubagentTitle: string;
    settingsSubagentDesc: string;
    settingsJobsTitle: string;
    settingsJobsDesc: string;
    settingsFenceTitle: string;
    settingsFenceDesc: string;
    fenceErrorReason: string;
    fenceDisableAction: string;
    settingsFontFamilyTitle: string;
    settingsFontFamilyDesc: string;
    settingsFontFamilyPlaceholder: string;
    settingsFontSizeTitle: string;
    settingsFontSizeDesc: string;
    settingsShellTitle: string;
    settingsShellDesc: string;
    settingsShellPlaceholder: string;
    settingsShellArgsTitle: string;
    settingsShellArgsDesc: string;
    settingsShellArgsPlaceholder: string;
    settingsTabsTitle: string;
    settingsViewersTitle: string;
    settingsGeneralTitle: string;
    settingsPopup: string;
    settingsViewerCatchAll: string;
    viewerImage: string;
    viewerPdf: string;
    viewerMarkdown: string;
    viewerCode: string;
    viewerBinary: string;
    viewerHtml: string;
    browser: string;
    browserPlaceholder: string;
    browserGo: string;
    browserBack: string;
    browserForward: string;
    browserStart: string;
    browserBlockedScheme: string;
    browserBlockedLoopback: string;
    browserInvalid: string;
    browserNoSandboxWarning: string;
    htmlNoSandboxWarning: string;
    sandboxStatusOn: string;
    sandboxUnlock: string;
    sandboxRestore: string;
    settingsHtmlDefaultUnsafeTitle: string;
    settingsHtmlDefaultUnsafeDesc: string;
    settingsHtmlSandboxTitle: string;
    settingsHtmlSandboxDesc: string;
    settingsBrowserSandboxTitle: string;
    settingsBrowserSandboxDesc: string;
    settingsBrowserLinksTitle: string;
    settingsBrowserLinksDesc: string;
    settingsBrowserHttpTitle: string;
    settingsBrowserHttpDesc: string;
    settingsBrowserHttpsTitle: string;
    settingsBrowserHttpsDesc: string;
    settingsBrowserLoopbackTitle: string;
    settingsBrowserLoopbackDesc: string;
    settingsBrowserLoopbackPlaceholder: string;
    browserOpenExternal: string;
    browserEmbedBlocked: string;
    browserEmbedBlockedDesc: string;
    browserEmbedAnyway: string;
    subagent: string;
    openSubagent: string;
    subagentMainAgent: string;
    subagentEmpty: string;
    subagentEmptyDesc: string;
    subagentRunning: string;
    subagentInactive: string;
    subagentModeOneShot: string;
    subagentModeContinuable: string;
    subagentCount: string;
    subagentCountRunning: string;
    subagentDiagCorrupt: string;
    subagentDiagUnsupported: string;
    subagentDiagUnavailable: string;
    subagentThinking: string;
    sideChat: string;
    sideChatNew: string;
    sideChatUntitled: string;
    sideChatEmpty: string;
    sideChatEmptyDesc: string;
    sideChatCreating: string;
    sideChatRetry: string;
    sideChatThreads: string;
    sideChatSave: string;
    sideChatSaveTitle: string;
    sideChatSaved: string;
    sideChatNoTurn: string;
    sideChatPendingDrop: string;
    sideChatFirstPlaceholder: string;
    sideChatComposerPlaceholder: string;
    sideChatThinking: string;
    sideChatThink: string;
    sideChatInjection: string;
    sideChatSend: string;
    sideChatCancel: string;
    sideChatCancelTitle: string;
    sideChatClose: string;
    sideChatCloseTitle: string;
    sideChatError: string;
    sideChatTurnUsage: string;
    sideChatBlockCollapse: string;
    sideChatBlockCollapseAria: string;
    sideChatBlockExpand: string;
    sideChatBlockExpandAria: string;
    sideChatBlockSignal: string;
    sideChatBlockExitCode: string;
    sideChatBlockRunning: string;
    sideChatBlockFailed: string;
    sideChatBlockDone: string;
    sideChatBlockNoOutput: string;
    sideChatBlockFiles: string;
    sideChatBlockWindow: string;
    sideChatConnDisconnected: string;
    sideChatConnReconnect: string;
    sideChatConnConnecting: string;
    sideChatConnRecovered: string;
    sideChatConnReconnectAction: string;
    sideChatConnRestartAction: string;
    jobs: string;
    jobsCount: string;
    jobsCountRunning: string;
    jobStatusRunning: string;
    jobStatusStopping: string;
    jobStatusCompleted: string;
    jobStatusKilled: string;
    jobStatusFailed: string;
    jobDurationSeconds: string;
    jobDurationMinutes: string;
    jobDurationHours: string;
    jobViewOutput: string;
    jobHideOutput: string;
    jobNoOutput: string;
    jobNotReadYet: string;
    jobOutputTruncated: string;
    jobOutputError: string;
    jobKill: string;
    jobKillConfirm: string;
    jobKillError: string;
    openPlugin: string;
    copyInstall: string;
    presetDshDesktopDesc: string;
};
/** The en dictionary (key-set-equal to zh, enforced by the type annotation). */
export declare const en: Record<keyof typeof zh, string>;
/**
 * The dictionary namespace this plugin owns in the DSH locale registry
 * (`'workbench'` is taken by DSH's own ui-workbench, hence this distinct name).
 */
export declare const LOCALE_NS = "workbenchEngine";
/**
 * Attach (or detach, with undefined) the DSH locale service. The workbench
 * mounts its own React root outside the slot system's locale seat, so the
 * service rides this module-level holder: components keep calling the plain
 * `t()` function, and the Workbench root's locale subscription re-renders the
 * whole tree on switches.
 */
export declare function attachLocale(service: {
    getSnapshot(): {
        active: string;
    };
} | undefined): void;
/** Translate a copy key in the active locale (zh → zh, else en). */
export type CopyKey = keyof typeof zh;
/** Translate a copy key; `{name}` placeholders interpolate from `params`. */
export declare function t(key: CopyKey, params?: Record<string, string | number>): string;
/** Whether the active locale is Chinese (used for selectors). */
export declare function isZh(): boolean;
/** Format an ISO 8601 author date relative to now (刚刚 / N 分钟前 / N 小时前 / 昨天 / date). */
export declare function relativeTime(iso: string): string;
//# sourceMappingURL=locales.d.ts.map