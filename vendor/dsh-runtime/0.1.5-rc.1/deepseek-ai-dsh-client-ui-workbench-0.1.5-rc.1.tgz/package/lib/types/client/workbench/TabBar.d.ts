/**
 * The tab strip of one pane: tabs capped at TAB_MAX_WIDTH (ellipsized),
 * overflow scrolls horizontally, a close button per tab, a four-way split
 * button cluster, and the + menu that opens new tabs (explorer / git /
 * terminal). Tabs are draggable; dropping onto another tab inserts before it,
 * dropping on the strip background appends to this pane. Right-clicking a
 * tab opens the tab context menu (close / close others / close to the left /
 * close to the right, the close ones scoped to this pane).
 */
import { type ReactNode } from 'react';
import type { WorkbenchTab } from './state.ts';
/** One + menu option. */
export interface NewTabOption {
    id: string;
    label: string;
    disabled?: boolean;
    /** Leading icon (Menu row). */
    icon?: ReactNode;
}
/** Drag payload for tab moves (HTML5 DnD dataTransfer). */
export declare const TAB_DRAG_TYPE = "application/x-dsh-tab";
export interface TabDragPayload {
    tabId: string;
    paneId: string;
}
export declare function serializeDrag(payload: TabDragPayload): string;
export declare function parseDrag(raw: string): TabDragPayload | null;
export declare function TabBar(props: {
    paneId: string;
    tabs: WorkbenchTab[];
    active: string | null;
    onActivate: (tabId: string) => void;
    onClose: (tabId: string) => void;
    onNewTab: (optionId: string) => void;
    newTabOptions: NewTabOption[];
    /** Drop of a tab from any pane: (payload, insertBeforeTabId | null). */
    onDropTab: (payload: TabDragPayload, before: string | null) => void;
    /**
     * Pin/unpin a terminal tab (v0.17.0+). Called with `'workspace'` or
     * `'global'` to pin (the shell snapshots the home cwd), or `null` to
     * unpin. Non-terminal tabs never trigger this callback. Optional: the
     * menu hides the pin entry when unset (legacy callers).
     */
    onPinTab?: ((tabId: string, scope: 'workspace' | 'global' | null) => void) | undefined;
    /** Icon resolver for tab labels (reads from the tab descriptor registry). */
    getTabIcon?: ((tab: WorkbenchTab) => ReactNode) | undefined;
    /** Badge resolver for tab labels (reads the descriptor's `badge`; the
     *  resolver returns the rendered pill or null). */
    getTabBadge?: ((tab: WorkbenchTab) => ReactNode) | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=TabBar.d.ts.map