import type { CopyProps } from './contract.ts';
export declare function ProjectTags({ tags, limit, ariaLabel }: {
    tags: readonly string[];
    limit?: number;
    ariaLabel?: string;
}): import("react").JSX.Element | null;
export declare function ProjectTagEditor({ value, t, suggestions, disabled, onChange, }: {
    t: CopyProps['t'];
    value: readonly string[];
    suggestions: readonly string[];
    disabled?: boolean;
    onChange: (tags: string[]) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=ProjectTagEditor.d.ts.map