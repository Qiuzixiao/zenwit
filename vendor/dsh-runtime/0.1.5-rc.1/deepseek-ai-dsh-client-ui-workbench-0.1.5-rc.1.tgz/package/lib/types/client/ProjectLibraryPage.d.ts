import type { CopyProps } from './contract.ts';
import type { ProjectSummary } from './project-api.ts';
export interface ProjectLibraryPageProps extends CopyProps {
    list: () => Promise<ProjectSummary[]>;
    openProject: (projectPath: string) => Promise<void>;
    deleteProject: (projectPath: string) => Promise<void>;
    forgetProject: (projectPath: string) => Promise<void>;
    onBack: () => void;
}
/** Full project library surface. The page owns a fresh scan so mutations are visible immediately. */
export declare function ProjectLibraryPage({ list, openProject, deleteProject, forgetProject, onBack, t }: ProjectLibraryPageProps): import("react").JSX.Element;
//# sourceMappingURL=ProjectLibraryPage.d.ts.map