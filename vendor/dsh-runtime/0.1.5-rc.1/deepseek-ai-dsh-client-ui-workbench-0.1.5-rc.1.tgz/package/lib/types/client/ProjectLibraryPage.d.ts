import type { CopyProps, Panel, WorkbenchProps } from './contract.ts';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { ProjectSummary } from './project-api.ts';
/** Library surface props: the scan, the surface actions, and the shared panel registry. */
export interface ProjectLibraryPageProps extends CopyProps {
    list: () => Promise<ProjectSummary[]>;
    openProject: (projectPath: string) => Promise<void>;
    deleteProject: (projectPath: string) => Promise<void>;
    forgetProject: (projectPath: string) => Promise<void>;
    openFolder: () => void;
    goHome: () => void;
    panels: readonly Panel[];
    activePanel: MainPanelId | null;
    selectPanel: (id: MainPanelId | null) => void;
    renderSlot: WorkbenchProps['renderSlot'];
}
/** Full project library surface. The page owns a fresh scan so mutations are visible immediately. */
export declare function ProjectLibraryPage({ list, openProject, deleteProject, forgetProject, openFolder, goHome, panels, activePanel, selectPanel, renderSlot, t, }: ProjectLibraryPageProps): import("react").JSX.Element;
//# sourceMappingURL=ProjectLibraryPage.d.ts.map