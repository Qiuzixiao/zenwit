/**
 * Per-session workbench state: the bottom workbench's split-pane tree, open
 * tabs, and the explorer expansion set. One state instance per conversation
 * id, persisted to localStorage under `dsh-workbench:v1:<id>` so a reload
 * restores the exact layout of the session it belongs to — switching
 * conversations swaps the whole state (memory + isolation).
 *
 * The split tree is a recursive structure: a leaf holds a tab group, a split
 * divides the space row- or column-wise with fractional sizes. All tree
 * operations are pure functions over the node, unit-tested in tests/state.spec.ts.
 */
import { type WorkbenchPrefs } from './prefs-shared.ts';
/**
 * Tab type identifier. Builtins register their ids (editor / git / terminal
 * / subagent / browser / diff) through the workbench service; external
 * plugins register their own (e.g. `'my-plugin:db'`). Kept as `string` so
 * the registry stays open.
 */
export type TabType = string;
/** What a diff tab shows: a worktree/index change of one path, or one commit's full patch. */
export type WorkbenchDiffRef = {
    kind: 'worktree';
    path: string;
    staged: boolean;
    untracked?: boolean | undefined;
    worktree?: string | undefined;
    repoRoot?: string | undefined;
} | {
    kind: 'commit';
    hash: string;
    hashFull: string;
    subject: string;
    worktree?: string | undefined;
    repoRoot?: string | undefined;
};
/** One open tab. `path` carries the file (editor) or is absent (git/terminal);
 *  `diff` carries the change a diff tab shows; `meta` (v0.12.0+) carries
 *  plugin-owned JSON-serializable state, preserved across reloads. */
export interface WorkbenchTab {
    id: string;
    type: TabType;
    title: string;
    path?: string;
    diff?: WorkbenchDiffRef;
    /** Plugin-owned state (v0.12.0+): MUST be JSON-serializable — it is
     *  persisted with the layout and restored verbatim on reload. */
    meta?: unknown;
    /** Pinned-terminal marker (v0.17.0+): a pinned terminal tab survives a
     *  session switch in its home session's state and surfaces in the
     *  PinnedRail of every session the scope allows. `homeCwd` is the cwd
     *  snapshot at pin time — a `workspace`-scoped pin is only visible to
     *  sessions whose cwd matches it. Absent = unpinned (legacy states). */
    pin?: {
        scope: 'workspace' | 'global';
        homeCwd?: string | undefined;
    };
}
/** A tab group. */
export interface WorkbenchLeaf {
    kind: 'leaf';
    id: string;
    tabs: WorkbenchTab[];
    active: string | null;
}
/** A recursive split between child panes (fractional sizes summing to 1). */
export interface WorkbenchSplit {
    kind: 'split';
    id: string;
    dir: 'row' | 'col';
    sizes: number[];
    children: SplitNode[];
}
export type SplitNode = WorkbenchLeaf | WorkbenchSplit;
/** The full per-session state. */
export interface WorkbenchState {
    /** The pane receiving newly opened tabs (the last pane the user touched). */
    activePane: string | null;
    /** Monotonic terminal tab counter (ids survive reloads). */
    nextTerminal: number;
    /** Monotonic browser tab counter (ids survive reloads; mirrors nextTerminal). */
    nextBrowser: number;
    /** Explorer expansion set (absolute directory paths). */
    expanded: string[];
    /**
     * Explorer rows highlighted by a "Show in folder" reveal (absolute paths).
     * Transient by design: sanitizeState never restores it, so a reload starts
     * unhighlighted.
     */
    revealed: string[];
    /** The workbench's split tree: the middle column's tabs and panes. */
    splits: SplitNode;
    /**
     * Live agent-terminal wait state (uuid → the wait the model currently
     * blocks on in `terminal_wait_for`), mirrored from the host's
     * agent-terminals push. Transient by design: sanitizeState never restores
     * it, so a reload starts clean and the next push (sent immediately on WS
     * attach) repopulates it.
     */
    agentWaits: Record<string, {
        needle: string;
        since: number;
    }>;
}
export declare const TAB_MAX_WIDTH = 160;
/** Mint a fresh uid-based tab id. The `'editor:' + path` convention only
 *  covers openWorkbenchFile opens (per-path dedupe); opens that must not
 *  dedupe (the tree's "open to the side") mint through here. */
export declare function mintTabId(): string;
/**
 * A fresh default state: one empty pane in the workbench. Nothing is seeded —
 * the empty pane's own cards offer the openable types, and files open into it
 * from the workspace's explorer column.
 */
export declare function makeDefaultState(): WorkbenchState;
/** Walk the tree and apply `visit` to the leaf with the given id. */
export declare function mapLeaf(node: SplitNode, paneId: string, visit: (leaf: WorkbenchLeaf) => void): SplitNode;
/** The first leaf of the tree (fallback pane when activePane is gone). */
export declare function firstLeaf(node: SplitNode): WorkbenchLeaf;
/** Find the leaf containing a tab id, if any. */
export declare function leafWithTab(node: SplitNode, tabId: string): WorkbenchLeaf | undefined;
/** All leaves of the tree, depth-first. */
export declare function allLeaves(node: SplitNode): WorkbenchLeaf[];
/** Whether a tab is open anywhere in the session's workbench. */
export declare function tabOpenIn(state: WorkbenchState, tabId: string): boolean;
/** Replace a leaf with a split of it plus a fresh empty leaf. */
export declare function splitLeafAt(node: SplitNode, paneId: string, dir: 'row' | 'col'): SplitNode;
/**
 * Split a leaf by inserting a fresh leaf holding `tab` beside it — the
 * VSCode drag-to-edge gesture. `dir` is the split direction ('row' for
 * left/right, 'col' for up/down); `front` places the new leaf first (left/
 * up) or second (right/down).
 * @returns the new tree plus the fresh leaf's id (the drop's active pane).
 */
export declare function insertLeafAt(node: SplitNode, paneId: string, dir: 'row' | 'col', tab: WorkbenchTab, front: boolean): {
    node: SplitNode;
    leafId: string;
};
/** Where a tab drop lands on a pane: an edge creates a split, center merges. */
export type DropZone = 'left' | 'right' | 'up' | 'down' | 'center';
/**
 * The VSCode drag gesture: move a tab out of its pane and either merge it
 * into the target pane (center) or split the target pane with the tab in a
 * fresh leaf (edge). The source pane collapses when it empties.
 */
export declare function moveTabToEdge(state: WorkbenchState, fromPane: string, tabId: string, toPane: string, zone: DropZone): WorkbenchState;
/**
 * Remove a leaf from the tree. A split left with one child promotes that
 * child; removing the last leaf yields an empty leaf.
 */
export declare function removeLeafAt(node: SplitNode, paneId: string): SplitNode;
/** Close a tab; an emptied leaf is removed (unless it is the only pane). */
export declare function closeTab(state: WorkbenchState, paneId: string, tabId: string): WorkbenchState;
/** Activate a tab in its pane (the pane's own tree). */
export declare function activateTab(state: WorkbenchState, paneId: string, tabId: string): WorkbenchState;
/** Update the display fields of one open tab (title / path / meta) without
 *  re-opening it. The browser tab persists its current URL and hostname
 *  title through this reducer so a reload restores the visited page. A
 *  missing tab id is a no-op. The tab may live in either tree or a free
 *  window. */
export declare function patchTab(state: WorkbenchState, tabId: string, patch: {
    title?: string;
    path?: string;
    meta?: unknown;
}): WorkbenchState;
/**
 * Set or clear the pin marker on one open tab (v0.17.0+). A pin marker is
 * structural metadata (NOT display fields like title/path), so it walks
 * the workbench's split tree exactly like {@link patchTab}. Passing `null` clears the pin
 * (the tab stays open in its home session); passing a `{ scope, homeCwd }`
 * object sets it. An unknown tab id is a strict no-op (same reference
 * returned) so a stale pin request never churns the state or rewrites
 * localStorage.
 * @param state - the current per-session workbench state.
 * @param tabId - the tab to pin/unpin.
 * @param pin - the pin marker to set, or null to clear.
 * @returns the next state (or the same reference when the tab is missing
 *          or the pin marker is already the requested value).
 */
export declare function setTabPin(state: WorkbenchState, tabId: string, pin: {
    scope: 'workspace' | 'global';
    homeCwd?: string | undefined;
} | null): WorkbenchState;
/**
 * Land a tab in the workbench's first pane — the plugin's own opens (its
 * bottom-panel + menu, the auto-terminal, and every open when no native
 * surface is installed): the plugin owns no right column any more (DSH's
 * native workbench is the right one), so the bottom workbench is the only tree.
 * @param state - the session state.
 * @param tab - the tab to land.
 * @returns the next state, with the bottom panel open.
 */
export declare function openTabInPane(state: WorkbenchState, tab: WorkbenchTab): WorkbenchState;
/** Move a tab from one pane to another (insert at index; -1 appends).
 *  The panes may live in DIFFERENT trees — dragging a tab between the two
 *  panels removes it from its own tree and lands it in the other one. */
export declare function moveTab(state: WorkbenchState, fromPane: string, tabId: string, toPane: string, index?: number): WorkbenchState;
/** Split the active pane (or the pane containing the active tab). */
export declare function splitPane(state: WorkbenchState, dir: 'row' | 'col'): WorkbenchState;
/**
 * Open a diff tab the VSCode way: an existing instance of the same change is
 * focused wherever it lives; otherwise the tab joins the first pane that
 * already holds diff tabs (diff panes are sticky — repeated clicks stack
 * there); on the FIRST diff of a layout the source pane splits vertically so
 * the diff lands in a fresh pane below it ("默认在下半栏新增一个").
 *
 * This is split-tree placement surgery, not registry dispatch: the diff tab
 * descriptor's `dedupeKey` is `(tab) => tab.id`, and the existing-instance
 * check below is exactly that rule — the two agree by construction (asserted
 * in tests). Diff tabs minted by the Git view carry change-derived ids, so
 * the id check is the per-change dedupe.
 * @returns the new state, with the diff pane active.
 */
export declare function openDiffTab(state: WorkbenchState, sourcePaneId: string, tab: WorkbenchTab): WorkbenchState;
/** Toggle a directory in the explorer expansion set. */
export declare function toggleExpanded(state: WorkbenchState, path: string): WorkbenchState;
/**
 * Reveal files in the explorer: expand every ancestor directory between the
 * explorer root and each file (so the lazy tree actually shows the row) and
 * record the paths for highlighting. The reveal set is transient —
 * sanitizeState never restores it, so a reload starts unhighlighted.
 * @param state - current workbench state.
 * @param cwd - the explorer's root (session working directory).
 * @param files - absolute paths to highlight (parent dirs are expanded).
 * @returns the next state, or the same reference when nothing is revealed.
 */
export declare function revealPaths(state: WorkbenchState, cwd: string | undefined, files: readonly string[]): WorkbenchState;
/** Adjust one split divider: `i` is the left/top child index, delta in fractions. */
export declare function resizeSplit(node: SplitNode, splitId: string, index: number, delta: number): SplitNode;
/** State-level {@link resizeSplit} route: the divider may live in either
 *  tree (split ids are globally unique). */
export declare function resizeSplitIn(state: WorkbenchState, splitId: string, index: number, delta: number): WorkbenchState;
/** Prefix marking a tab id as an agent-owned terminal (suffix is the uuid). */
export declare const AGENT_TAB_PREFIX = "agent:";
/** Whether a tab id refers to an agent-owned terminal. */
export declare function isAgentTabId(tabId: string): boolean;
/** Extract the agent terminal uuid from an `agent:<uuid>` tab id. */
export declare function agentUuidOf(tabId: string): string;
/** Build the workbench tab id for one agent terminal uuid. */
export declare function agentTabId(uuid: string): string;
/**
 * Reconcile the workbench's agent-terminal tabs with the host's live list.
 * The host pushes the current list of agent terminals (created by the model
 * through the `terminal_create` tool) over a dedicated WebSocket; this
 * reducer mirrors that list into tabs: new uuids get a tab, vanished uuids
 * lose theirs. The agent owns the lifetime — the user closing a tab sends a
 * WS close frame that kills the pty, which fires a change, which converges
 * the view. Idempotent: a no-op when the lists already match.
 * @param state - the current per-session workbench state.
 * @param agentTerminals - the live agent terminal snapshots from the host.
 * @returns the next state (or the same reference if no change was needed).
 */
export declare function reconcileAgentTerminals(state: WorkbenchState, agentTerminals: ReadonlyArray<{
    uuid: string;
    title: string;
    waiting?: {
        needle: string;
        since: number;
    } | null;
}>): WorkbenchState;
/**
 * Mirror ONLY the authoritative agent-wait map from a push — no tab
 * add/remove reconciliation. Used while the `terminal` tab type is disabled:
 * the tab surface is frozen, but a wait that resolves during that window
 * must still clear its banner state, or a re-enabled terminal keeps a stale
 * banner/⏳ until some unrelated host event fires the next full reconcile.
 * Idempotent: a no-op when the map already matches.
 */
export declare function mirrorAgentWaits(state: WorkbenchState, agentTerminals: ReadonlyArray<{
    uuid: string;
    title: string;
    waiting?: {
        needle: string;
        since: number;
    } | null;
}>): WorkbenchState;
/**
 * Cross-session panel width: the last dragged width, shared by EVERY
 * conversation (the panel width is a layout preference, not per-session
 * content). Written on every persist, read at session load and on
 * cache-hit session switches, so a drag in one conversation carries to all
 * the others (last drag wins).
 */
/** Immutable snapshot handed to React (replaced only on real changes). */
export interface WorkbenchSnapshot {
    project: string | undefined;
    state: WorkbenchState | undefined;
    /**
     * The current side card prefs. Carried IN the snapshot (not a separate
     * subscription) so prefs changes re-render the consumers that gate on
     * them — the + menu hides a tab type the moment its switch flips.
     */
    prefs: WorkbenchPrefs;
}
/**
 * Structural validation of one persisted state. A malformed or stale shape
 * (older layouts, hand-edited storage) must fall back to the default instead
 * of crashing the panel on every reload; the restored width is also clamped
 * to the current viewport so a stale fullscreen width can never crush the
 * app shell (margin-right larger than the window) or cover the whole screen.
 * @returns a clean state, or undefined to fall back to the default.
 */
export declare function sanitizeState(parsed: unknown): WorkbenchState | undefined;
/** The session-scoped store: one state per conversation, localStorage-backed. */
export declare class WorkbenchStore {
    private readonly byProject;
    private snapshot;
    private readonly listeners;
    /** Per-session persist debounce timers (v0.12.0+: one per session, so a
     *  targeted open never cancels another session's pending write). */
    private readonly persistTimers;
    /** User-facing side card prefs seeding brand-new session states (defaults until the settings RPC resolves). */
    private prefs;
    /** The displayed conversation (not a key; see {@link setActiveSession}). */
    private activeSession;
    /**
     * Replace the side card prefs (the settings RPC result / settings page
     * write). Notifies like any store change: the snapshot carries the prefs,
     * so consumers that gate on enable switches (the + menu, derived flows)
     * re-render with the new values immediately.
     */
    setPrefs(prefs: WorkbenchPrefs): void;
    /** The current side card prefs (seeds new sessions; persisted states win). */
    getPrefs(): WorkbenchPrefs;
    /**
     * The conversation the workbench is currently displayed for. Not a key: the
     * layout belongs to the PROJECT. Views and the service read it to tell "the
     * user switched conversation" (park a terminal) from "the tab was closed"
     * (release it), and to scope host callbacks.
     */
    setActiveSession(sessionId: string | undefined): void;
    /** The conversation the workbench is displayed for (see {@link setActiveSession}). */
    getActiveSession(): string | undefined;
    /** Select a session (or none); loads its persisted state. */
    setProject(project: string | undefined): void;
    subscribe(listener: () => void): () => void;
    getSnapshot(): WorkbenchSnapshot;
    /** Mutate the current session's state (no-op without a session). */
    update(mutator: (draft: WorkbenchState) => void): void;
    /**
     * Whether a tab still exists in its session's state. Views use this on
     * unmount to tell "the tab was closed" (release the terminal now) from
     * "the tree re-rendered / the conversation switched" (the tab is still
     * open — keep the terminal alive through the host's reconnect grace).
     * Checks the session's own map entry (the current snapshot may already
     * point at another session when a conversation switch unmounts the old
     * one's tabs).
     */
    tabOpen(project: string, tabId: string): boolean;
    /**
     * Read-only view of EVERY cached session's state (v0.17.0+). The
     * PinnedRail uses this to collect pinned terminals across sessions
     * without each render reading private fields. The map is the live
     * `byProject` reference — callers MUST treat it as read-only (mutations
     * go through {@link reduce} / {@link reduceFor}). A session that has
     * never been visited in this run is absent (its pinned tabs are not
     * visible until first load — accepted as YAGNI by the design).
     */
    getProjectStates(): ReadonlyMap<string, WorkbenchState>;
    /** Apply a pure reducer (returns the next state). */
    reduce(reducer: (state: WorkbenchState) => WorkbenchState): void;
    /**
     * Apply a pure reducer to a TARGET session's state (not the active one),
     * loading it on demand and persisting the result — WITHOUT switching the
     * active snapshot or notifying (the UI must not follow along). Used by the
     * service's targeted `openTab(seed, scope)`: the open lands in the target
     * session's layout and is visible whenever the user switches to it.
     */
    reduceFor(project: string, reducer: (state: WorkbenchState) => WorkbenchState): void;
    private schedulePersist;
    private notify;
}
/**
 * Create one workbench store instance. Production code calls this only from
 * the client plugin's `apply` (the instance is handed to components as a
 * prop); tests call it directly. No module-level singleton: the store's
 * lifetime belongs to the plugin activation, exactly like the official
 * `createXXXStore()` factory rule.
 */
export declare function createWorkbenchStore(): WorkbenchStore;
//# sourceMappingURL=state.d.ts.map