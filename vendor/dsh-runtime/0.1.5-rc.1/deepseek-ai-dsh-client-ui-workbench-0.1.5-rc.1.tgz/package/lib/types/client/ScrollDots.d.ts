import type { RefObject } from 'react';
/** Floating handles only replace the vertical scrollbar; native scrolling stays intact. */
export declare function ScrollDots({ root, label }: {
    root: RefObject<HTMLDivElement>;
    label: string;
}): import("react").JSX.Element;
//# sourceMappingURL=ScrollDots.d.ts.map