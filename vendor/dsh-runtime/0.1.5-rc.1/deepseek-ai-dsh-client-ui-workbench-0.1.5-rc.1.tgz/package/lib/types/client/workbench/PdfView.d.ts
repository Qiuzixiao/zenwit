import { type SessionScope } from './api.ts';
export declare function PdfView(props: {
    scope: SessionScope;
    path: string;
    title: string;
}): import("react").JSX.Element;
//# sourceMappingURL=PdfView.d.ts.map