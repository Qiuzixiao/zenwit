import type { PropsRuntime, PropsRenderSlots } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { FileRequest, CopyProps, WorkbenchProps } from './contract.ts';
/** One workspace pane props. */
export type WorkspaceProps = PropsRuntime<'root'> & PropsRenderSlots<'main' | 'sidebar.settings' | 'sidebar.footer.action'> & CopyProps & Pick<WorkbenchProps, 'searchSessions' | 'renameSession' | 'archiveSession' | 'forkSession' | 'usePendingActions' | 'useNavigation' | 'guardNavigation'> & {
    projectPath: string;
    closeProject: () => Promise<void>;
    registerCloseRequest?: (request: () => void) => () => void;
    openSession: (id: SessionId) => void;
    startSession: (workspaceId: WorkspaceId) => void;
    addSelectionToConversation: (target: 'current' | 'new', context: string, label?: string, path?: string) => Promise<void>;
    request: typeof fetch;
    fileRequest: FileRequest | null;
    fileRevision: number;
};
/** Three-pane workspace (see module doc). */
export declare function Workspace(props: WorkspaceProps): import("react").JSX.Element;
//# sourceMappingURL=Workspace.d.ts.map