import type { PropsRuntime, PropsRenderSlots } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { FileRequest, CopyProps, WorkbenchProps } from './contract.ts';
import type { DocumentRenderers } from './document-renderers.ts';
/** One workspace pane props: the engine surface's host and the conversation column. */
export type WorkspaceProps = PropsRuntime<'root'> & PropsRenderSlots<'main'> & CopyProps & Pick<WorkbenchProps, 'engine' | 'searchSessions' | 'renameSession' | 'archiveSession' | 'forkSession' | 'usePendingActions' | 'useNavigation' | 'useDocumentRendererRevision' | 'guardNavigation'> & {
    projectPath: string;
    closeProject: () => Promise<void>;
    registerCloseRequest?: (request: () => void) => () => void;
    openSession: (id: SessionId) => void;
    startSession: (workspaceId: WorkspaceId) => void;
    addSelectionToConversation: (target: 'current' | 'new', context: string, label?: string, path?: string) => Promise<void>;
    request: typeof fetch;
    documentRenderers: DocumentRenderers;
    fileRequest: FileRequest | null;
    fileRevision: number;
};
/** Explorer, engine surface and conversation column (see module doc). */
export declare function Workspace(props: WorkspaceProps): import("react").JSX.Element;
//# sourceMappingURL=Workspace.d.ts.map