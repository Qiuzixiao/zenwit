import type { Context } from './workbench-context.ts';
import { type SessionScope } from './api.ts';
import type { WorkbenchStore, WorkbenchTab } from './workbench-store.ts';
export declare function EditorHost(props: {
    ctx: Context;
    store: WorkbenchStore;
    scope: SessionScope;
    tab: WorkbenchTab;
}): import("react").JSX.Element;
//# sourceMappingURL=WorkbenchEditor.d.ts.map