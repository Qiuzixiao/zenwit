import type { CopyProps } from '../contract.ts';
import type { DocumentDescriptor } from '../document-descriptor.ts';
import type { DocumentRenderers } from '../document-renderers.ts';
/**
 * Render the preview selected by the descriptor: a built-in family drawn here,
 * or a plugin view loaded once through the registry.
 * @param props - the descriptor, registry, draft source and change revision.
 * @returns the preview, a loading status, or a notice when nothing can draw it.
 */
export declare function DocumentPreview({ descriptor, renderers, path, source, revision, request, t }: {
    descriptor: DocumentDescriptor;
    renderers: DocumentRenderers;
    path: string;
    source: string;
    revision: number;
    request: typeof fetch;
} & CopyProps): import("react").JSX.Element;
//# sourceMappingURL=DocumentPreview.d.ts.map