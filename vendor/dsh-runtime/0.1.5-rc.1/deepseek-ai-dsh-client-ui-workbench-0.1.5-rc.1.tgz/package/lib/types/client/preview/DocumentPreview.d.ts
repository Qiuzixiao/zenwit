import type { CopyProps } from '../contract.ts';
/** @param props - document path, unsaved source and change revision. @returns the file's preview. */
export declare function DocumentPreview({ path, source, revision, request, t }: {
    path: string;
    source: string;
    revision: number;
    request: typeof fetch;
} & CopyProps): import("react").JSX.Element;
//# sourceMappingURL=DocumentPreview.d.ts.map