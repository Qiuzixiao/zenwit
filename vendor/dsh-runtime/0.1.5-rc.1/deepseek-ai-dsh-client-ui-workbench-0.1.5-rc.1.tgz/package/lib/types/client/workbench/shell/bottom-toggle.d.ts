/**
 * The bottom workbench's expand/collapse control, registered into DSH's
 * session header utilities list (`conversation.session.header.utilities`).
 *
 * DSH 0.1.5 draws its own right-Workbench expand button in the header's corner
 * slot (`conversation.session.header.corner`, a SINGLE slot owned by the
 * native workbench package), so the plugin cannot take that seat. The utilities
 * list sits immediately left of it — the same row as the host's "Session
 * log" capsule — which is where a dock toggle belongs: in flow, so it never
 * overlaps host chrome and needs no absolute positioning or measurement.
 *
 * Registration goes through `slots.inject` because the declaration may not be
 * on the ledger yet at plugin activation (the ui-conversation parent entry
 * declares it); the callback re-runs if the declaration collapses and is
 * re-declared. `order: 10` places the button after the host's own utilities.
 */
import type { Context } from '../workbench-context.ts';
import type { WorkbenchStore } from '../state.ts';
/** Register the header toggle; returns the disposer. */
export declare function registerBottomToggle(ctx: Context, store: WorkbenchStore): () => void;
//# sourceMappingURL=bottom-toggle.d.ts.map