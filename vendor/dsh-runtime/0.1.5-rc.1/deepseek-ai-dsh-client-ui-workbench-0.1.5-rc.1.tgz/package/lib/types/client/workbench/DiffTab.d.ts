import type { WorkbenchDiffRef } from './workbench-store.ts';
export declare function DiffTab(props: {
    sessionId: string;
    cwd: string | undefined;
    diff: WorkbenchDiffRef;
}): import("react").JSX.Element;
//# sourceMappingURL=DiffTab.d.ts.map