import type { WorkbenchEngineService } from './service.ts';
import { type WorkbenchStore } from './state.ts';
export declare function ExplorerPane(props: {
    store: WorkbenchStore;
    /** The project directory this pane lists. */
    projectPath: string;
    /** The conversation session id, or '' before one exists. */
    sessionId: string;
    service?: WorkbenchEngineService | undefined;
    onOpenFile: (path: string) => void;
    onReferenceFile: (path: string, isDir: boolean) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=ExplorerPane.d.ts.map