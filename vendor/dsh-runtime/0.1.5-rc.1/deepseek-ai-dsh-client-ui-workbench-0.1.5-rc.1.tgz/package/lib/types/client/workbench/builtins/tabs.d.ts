/**
 * The built-in tab descriptors: the plugin registers its own pages
 * (editor / git — the unified changes tab / subagent / sidechat / terminal /
 * browser / diff) through
 * the same {@link WorkbenchEngineService} external plugins use — eating its
 * own dogfood. The terminal descriptor owns its quota (`TERMINAL_LIMIT`)
 * and mints `terminal:<uuid>` ids through `createTab`; the browser mints
 * `browser:<n>` the same way (no quota). The editor tab is the file view;
 * the explorer is the workspace's own left column.
 */
import type { Context } from '../workbench-context.ts';
import type { TabDescriptor } from '../service.ts';
/** How many UI-owned terminals may be open at once (agent-owned ones are uncapped). */
export declare const TERMINAL_LIMIT = 3;
/** Optional per-registration builtin behavior (currently terminal title). */
export interface BuiltinTabOptions {
    /** Returns the display title for newly opened terminal tabs. */
    terminalTitle?: () => string;
}
/** The 6 built-in tab descriptors. */
export declare function builtinTabs(_ctx: Context, options?: BuiltinTabOptions): readonly TabDescriptor[];
//# sourceMappingURL=tabs.d.ts.map