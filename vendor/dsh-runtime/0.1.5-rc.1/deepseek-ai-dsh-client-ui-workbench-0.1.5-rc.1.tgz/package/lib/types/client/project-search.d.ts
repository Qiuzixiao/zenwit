/** Project list filtering shared by the home and project-library surfaces. */
import type { ProjectSummary } from './project-api.ts';
/** Tags carried by one project; the library wire may omit the field entirely. */
export declare function projectTags(project: ProjectSummary): string[];
/** True when the query appears in a project's name, path, or tags. */
export declare function projectMatches(project: ProjectSummary, query: string): boolean;
//# sourceMappingURL=project-search.d.ts.map