/** File presentation capabilities shared by tabs, previews and source editors. */
export type DocumentKind = 'markdown' | 'html' | 'svg' | 'image' | 'pdf' | 'text';
/**
 * Resolve the built-in presentation kind for a local filename.
 * @param path - local filename.
 * @returns the built-in document presentation.
 */
export declare function documentKind(path: string): DocumentKind;
/**
 * Whether a local filename has a binary-only reader.
 * @param path - local filename.
 * @returns whether only binary preview is available.
 */
export declare function isBinaryDocument(path: string): boolean;
/**
 * Whether a local filename can switch between preview and source.
 * @param path - local filename.
 * @returns whether preview and source can be switched.
 */
export declare function hasDocumentPreview(path: string): boolean;
/**
 * Resolve the image MIME type used for a Blob preview.
 * @param path - local filename.
 * @returns image MIME type for a Blob preview.
 */
export declare function imageMime(path: string): string;
//# sourceMappingURL=document-types.d.ts.map