/** File presentation capabilities shared by tabs, previews and source editors. */
export type DocumentKind = 'markdown' | 'html' | 'svg' | 'image' | 'pdf' | 'text';
/** @param path - local filename. @returns the built-in document presentation. */
export declare function documentKind(path: string): DocumentKind;
/** @param path - local filename. @returns whether only binary preview is available. */
export declare function isBinaryDocument(path: string): boolean;
/** @param path - local filename. @returns whether preview and source can be switched. */
export declare function hasDocumentPreview(path: string): boolean;
/** @param path - local filename. @returns image MIME type for a Blob preview. */
export declare function imageMime(path: string): string;
//# sourceMappingURL=document-types.d.ts.map