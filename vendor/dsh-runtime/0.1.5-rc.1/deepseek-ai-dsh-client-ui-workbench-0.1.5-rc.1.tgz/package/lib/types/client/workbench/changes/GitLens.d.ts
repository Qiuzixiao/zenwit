import type { SessionScope } from '../api.ts';
import type { WorkbenchDiffRef, WorkbenchStore } from '../workbench-store.ts';
export interface GitLensProps {
    scope: SessionScope;
    /** The workbench store: reads the `workspaceFence` pref (see the open guard below). */
    store: WorkbenchStore;
    onOpenFile: (path: string) => void;
    /** Preview one change in the shared bottom pane (worktree or commit ref). */
    onPreview: (ref: WorkbenchDiffRef) => void;
    /** The ref currently previewed (row highlight); null when the pane is closed. */
    selectedRef: WorkbenchDiffRef | null;
    /** Poll only while the tab is actually visible. */
    visible: boolean;
}
export declare function GitLens(props: GitLensProps): import("react").JSX.Element;
//# sourceMappingURL=GitLens.d.ts.map