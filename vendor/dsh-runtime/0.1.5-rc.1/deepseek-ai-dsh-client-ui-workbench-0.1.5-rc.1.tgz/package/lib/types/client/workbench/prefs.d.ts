/**
 * Client-side read of the user-facing workbench preferences. The host owns
 * the namespace through the settings seam (in-process); the DSH settings RPC
 * domain only serves allowlisted namespaces to configuration clients, so the
 * client reads and writes THIS namespace through the plugin's own fenced
 * /workbench routes instead (api.settingsGet/settingsUpdate). Any failure
 * (route rejected, namespace absent, a field of the wrong type, a value out
 * of the contract range) falls back to the schema defaults — the workbench
 * must keep working exactly as composed when the settings surface is missing.
 */
import type { api } from './api.ts';
import { clampTerminalFontSize, SIDEBAR_PREFS_DEFAULTS, type WorkbenchPrefs } from './prefs-shared.ts';
export { SIDEBAR_PREFS_DEFAULTS, clampTerminalFontSize, };
export type { WorkbenchPrefs };
/** The settings wire face the preferences need (a subset of the plugin api). */
export type WorkbenchSettingsClient = Pick<typeof api, 'settingsGet' | 'settingsUpdate'>;
/** Validate one raw resolved value into {@link WorkbenchPrefs}. Used for the
 * settings.get payload AND the settings.update response (both carry the
 * layered resolved value); any malformed field falls back to its default.
 * @param value - the raw resolved section from the settings wire.
 * @returns validated prefs (always well-formed).
 */
export declare function parsePrefs(value: unknown): WorkbenchPrefs;
/**
 * Read the resolved workbench preferences through the plugin's settings route.
 * @param settings - the settings wire face (the plugin api by default).
 * @returns validated prefs, or the schema defaults when the route rejects,
 * the namespace is absent, or a stored value violates the contract.
 */
export declare function loadPrefs(settings: WorkbenchSettingsClient): Promise<WorkbenchPrefs>;
/** The boot prefs: one settings fetch, with the schema defaults on failure (a
 *  stalled wire must not keep the workbench unmounted). */
export interface BootDecision {
    prefs: WorkbenchPrefs;
}
export declare function loadBootDecision(settings: WorkbenchSettingsClient): Promise<BootDecision>;
//# sourceMappingURL=prefs.d.ts.map