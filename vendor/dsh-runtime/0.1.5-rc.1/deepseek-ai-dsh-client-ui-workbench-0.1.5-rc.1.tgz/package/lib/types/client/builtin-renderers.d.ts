import type { RendererDeclaration, RendererId } from './document-descriptor.ts';
import type { DocumentRenderers } from './document-renderers.ts';
/** Renderer ids of the kernel's read-only previews. */
export declare const BUILTIN_RENDERER_IDS: {
    readonly html: "builtin/html";
    readonly svg: "builtin/svg";
    readonly image: "builtin/image";
    readonly pdf: "builtin/pdf";
    readonly video: "builtin/video";
    readonly audio: "builtin/audio";
};
/**
 * Whether a renderer id names a kernel built-in the Workbench renders itself.
 * @param id - the descriptor's selected renderer id.
 * @returns whether the id is a built-in read-only preview.
 */
export declare function isBuiltinRendererId(id: RendererId): boolean;
/**
 * The built-in read-only declarations. `image/*` is intentionally a wildcard:
 * an exact media-type match outranks it, so a future format-specific built-in
 * can be added without touching this row.
 */
export declare const BUILTIN_RENDERER_DECLARATIONS: readonly RendererDeclaration[];
/**
 * Register every built-in read-only renderer.
 * @param renderers - the Workbench registry to populate.
 * @returns one disposer removing every built-in registered here.
 */
export declare function registerBuiltinRenderers(renderers: DocumentRenderers): () => void;
//# sourceMappingURL=builtin-renderers.d.ts.map