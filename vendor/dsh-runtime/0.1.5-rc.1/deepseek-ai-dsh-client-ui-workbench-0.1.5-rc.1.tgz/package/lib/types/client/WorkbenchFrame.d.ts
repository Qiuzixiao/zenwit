import type { WorkbenchProps } from './contract.ts';
/** @param props - root hooks, child slots and typed commands supplied by the renderer. */
export declare function WorkbenchFrame(props: WorkbenchProps): import("react").JSX.Element;
//# sourceMappingURL=WorkbenchFrame.d.ts.map