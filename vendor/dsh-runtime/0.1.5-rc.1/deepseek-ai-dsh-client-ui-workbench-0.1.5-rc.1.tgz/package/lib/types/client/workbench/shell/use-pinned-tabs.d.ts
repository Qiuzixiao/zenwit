import { type WorkbenchSnapshot, type WorkbenchStore, type SplitNode } from '../workbench-store.ts';
import type { WorkbenchActions } from '../WorkbenchSplit.tsx';
export declare function usePinnedTabs(input: {
    store: WorkbenchStore;
    sessionId: string | undefined;
    cwd: string | undefined;
    snapshot: WorkbenchSnapshot;
    actions: WorkbenchActions;
}): {
    augmentedTree: SplitNode | undefined;
    wrappedActions: WorkbenchActions;
};
//# sourceMappingURL=use-pinned-tabs.d.ts.map