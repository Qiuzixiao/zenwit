import type { Context } from './workbench-context.ts';
import { type WorkbenchStore } from './workbench-store.ts';
export declare function Workbench(props: {
    ctx: Context;
    store: WorkbenchStore;
}): import("react").JSX.Element;
//# sourceMappingURL=Workbench.d.ts.map