/** Pure PDF extension dispatch, separate from React for unit testing. */
export declare function isPdfExt(ext: string): boolean;
//# sourceMappingURL=pdf-types.d.ts.map