/** A parse failure keeps nothing of the input: the caller shows the error. */
export declare function sanitizeSvg(svg: string): string;
//# sourceMappingURL=mermaid-sanitize.d.ts.map