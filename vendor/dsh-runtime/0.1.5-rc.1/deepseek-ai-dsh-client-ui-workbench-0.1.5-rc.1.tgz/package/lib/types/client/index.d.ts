/** Sole browser root: generic projects, editing and slot-composed conversation. */
import type { Context } from '@deepseek-ai/cordis';
export type { WorkbenchFiles } from './contract.ts';
/** Required typed capabilities; visual owners arrive through declared slots. */
export declare const inject: string[];
/**
 * Install the standalone root and its file-link service with fiber-owned teardown.
 * @param ctx - current browser plugin context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map