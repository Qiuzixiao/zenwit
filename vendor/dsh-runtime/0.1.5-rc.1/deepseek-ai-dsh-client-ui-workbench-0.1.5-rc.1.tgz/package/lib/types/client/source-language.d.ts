/** CodeMirror language selection, including the original DSH file suffix aliases. */
import { LanguageDescription } from '@codemirror/language';
/**
 * Select the lazy CodeMirror grammar for a file path.
 * @param path - file path, including its extension.
 * @returns a lazy grammar, or `undefined` when no language matches.
 */
export declare function sourceLanguage(path: string): LanguageDescription | undefined;
//# sourceMappingURL=source-language.d.ts.map