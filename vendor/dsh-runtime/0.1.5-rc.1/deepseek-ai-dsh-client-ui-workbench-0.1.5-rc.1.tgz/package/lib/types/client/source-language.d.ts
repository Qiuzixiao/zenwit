/** CodeMirror language selection, including the original DSH file suffix aliases. */
import { LanguageDescription } from '@codemirror/language';
/** @param path - file path, including its extension. @returns a lazy grammar, if known. */
export declare function sourceLanguage(path: string): LanguageDescription | undefined;
//# sourceMappingURL=source-language.d.ts.map