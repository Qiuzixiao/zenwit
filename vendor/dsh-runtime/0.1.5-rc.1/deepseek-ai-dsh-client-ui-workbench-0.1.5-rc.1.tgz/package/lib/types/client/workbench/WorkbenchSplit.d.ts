import type { ReactNode } from 'react';
import type { WorkbenchState, WorkbenchTab, SplitNode } from './workbench-store.ts';
import type { DropZone } from './workbench-store.ts';
import { type NewTabOption, type TabDragPayload } from './WorkbenchTabs.tsx';
/** Actions the workbench needs (bound to the store by the workbench shell). */
export interface WorkbenchActions {
    closeTab: (paneId: string, tabId: string) => void;
    activateTab: (paneId: string, tabId: string) => void;
    /** Make a pane the target of newly opened tabs (click focus). */
    focusPane: (paneId: string) => void;
    /** VSCode drag gesture: edge → split the target pane, center → merge. */
    moveTabToEdge: (payload: TabDragPayload, toPane: string, zone: DropZone) => void;
    /** Reorder within a pane (drop onto another tab inserts before it). */
    moveTabBefore: (payload: TabDragPayload, toPane: string, beforeTabId: string) => void;
    resizeSplit: (splitId: string, index: number, deltaFrac: number) => void;
    /**
     * Pin/unpin a terminal tab (v0.17.0+). The shell snapshots the home cwd
     * at pin time; null clears the pin. Optional: when undefined the tab
     * context menu hides the pin entry (legacy callers).
     */
    pinTab?: ((tabId: string, scope: 'workspace' | 'global' | null) => void) | undefined;
}
/** The workbench: the split tree filling the workbench body. `tree` selects
 *  which tree renders (the right panel's by default; the bottom panel passes
 *  `state.splits` — the actions route by pane id, so one action set
 *  serves both). */
export declare function Workbench(props: {
    state: WorkbenchState;
    tree?: SplitNode | undefined;
    newTabOptions: NewTabOption[];
    actions: WorkbenchActions;
    onNewTab: (optionId: string) => void;
    renderTab: (tab: WorkbenchTab, active: boolean, paneId: string) => ReactNode;
    getTabIcon?: ((tab: WorkbenchTab) => ReactNode) | undefined;
    getTabBadge?: ((tab: WorkbenchTab) => ReactNode) | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=WorkbenchSplit.d.ts.map