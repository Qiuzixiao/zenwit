export type EditorMode = 'markdown' | 'text';
/** A non-empty editor selection, positioned in viewport coordinates. */
export interface DocumentSelection {
    /** The selected text as it appears in the editor. */
    text: string;
    /** Start offset in the editor document. */
    from: number;
    /** End offset in the editor document. */
    to: number;
    /** One-based line containing the selection start. */
    startLine: number;
    /** One-based line containing the selection end. */
    endLine: number;
    /** Bounding viewport rectangle for the selection. */
    rect: {
        left: number;
        top: number;
        right: number;
        bottom: number;
    };
}
export interface EditorProps {
    path?: string;
    reveal?: {
        line: number | undefined;
        sequence: number;
    } | null;
    externalUpdate?: {
        content: string;
    } | undefined;
    initialDoc: string;
    onChange: (doc: string) => void;
    onSelectionChange?: (selection: DocumentSelection | null) => void;
    mode?: EditorMode;
}
/** Editor (keyed by the parent per open document). */
export declare function Editor({ initialDoc, externalUpdate, onChange, onSelectionChange, mode, reveal, path }: EditorProps): import("react").JSX.Element;
/** Commands and availability for one live visual editor instance. */
export interface EditorHistory {
    canUndo: boolean;
    canRedo: boolean;
    undo: () => void;
    redo: () => void;
}
/** Search operations owned by one live visual editor. */
export interface EditorNavigation {
    find: (query: string, direction: 'first' | 'next' | 'previous' | 'count') => {
        index: number;
        total: number;
    };
    headings: () => Array<{
        title: string;
        level: number;
        position: number;
    }>;
    jump: (position: number) => void;
    text: () => string;
    focus: () => void;
}
interface VisualEditorProps {
    externalUpdate?: {
        content: string;
    } | undefined;
    initialDoc: string;
    onChange: (doc: string) => void;
    onSelectionChange?: (selection: DocumentSelection | null) => void;
    onHistoryChange?: (history: EditorHistory | null) => void;
    onNavigationChange?: (navigation: EditorNavigation | null) => void;
}
/** MilkdownProvider owns the editor context for the visual editor instance. */
export declare function VisualEditor(props: VisualEditorProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Editor.d.ts.map