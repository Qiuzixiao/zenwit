/** Layout service, panel-selection hooks, and document theme presentation. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { PanelInfo } from './service.ts';
export { LayoutController } from './service.ts';
export type { ILayout, MainPanelId, PanelInfo } from './service.ts';
/** Selector hook over root-scoped panel selection. */
export type UsePanelInfo = SnapshotSelectorHook<PanelInfo>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The outward face only; the concrete service stays inside this plugin. */
        layout: import('./service.ts').ILayout;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface GlobalStandardProps {
        /** Subscribe to the selected main panel independently of parent renders. */
        usePanelInfo: UsePanelInfo;
    }
    interface SlotMap {
        /** Optional sidebar seat declared by a visual shell. */
        'sidebar': {
            kind: 'single';
            scope: 'root';
            owner: SidebarOwnerProps;
        };
        /**
         * Central panel selected by sidebar entry id. The reserved `conversation`
         * key hosts the Conversation; other keys receive no Session binding.
         */
        'main': {
            kind: 'keyed';
            scope: 'root';
        };
        /** Optional right-panel seat declared by a visual shell. */
        'rightbar': {
            kind: 'single';
            scope: 'root';
            owner: RightbarOwnerProps;
        };
        /**
         * Frame-wide floating layer, above every column and outside their scroll
         * containers. Deliberately generic and unowned by any feature: a badge, a
         * toast stack or a status pill all belong here, and entries order among
         * themselves. The layer itself is click-through — entries opt back into
         * pointer events — so an occupant never blocks the app underneath.
         *
         * This is the additive seat for a frame-wide surface of your own: a fresh
         * `id` is added beside the shipped entries instead of replacing them.
         */
        'shell.overlay': {
            kind: 'list';
            scope: 'root';
        };
    }
}
/** Sidebar owner share: live column state from the frame's concession solve. */
export interface SidebarOwnerProps {
    /** True when the sidebar is closed (the column renders the compact control rail). */
    collapsed: boolean;
    /** Rendered column width in pixels. */
    width: number;
}
/** Right column owner share: resolved normal geometry and opening eligibility. */
export interface RightbarOwnerProps {
    /** Resolved normal panel width in px, not the saved preference; zero if it cannot fit. */
    width: number;
    /** Current frame width in px. */
    viewportWidth: number;
    /**
     * Whether a normal right panel can retain 300px beside a 400px center.
     * Before a narrow opening, includes the space from collapsing the left sidebar.
     */
    canShow: boolean;
}
/** Required services (cordis fiber inject — the loader passes all module exports as an object plugin). */
export declare const inject: string[];
/**
 * Provide layout navigation and root panel hooks without registering a visual root.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map