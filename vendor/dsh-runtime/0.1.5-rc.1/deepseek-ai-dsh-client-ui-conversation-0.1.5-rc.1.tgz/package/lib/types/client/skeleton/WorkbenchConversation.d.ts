import type { ConversationSlotProps } from '../contract/slots.ts';
/** Full props composed from the slot contract. */
export type WorkbenchConversationProps = ConversationSlotProps;
export declare function WorkbenchConversation({ sessionId, useSession, useSessions, useSessionPendingInteraction, useConversation, useInput, useComposerBlock, renderSlot, renderSlotChain, t, }: WorkbenchConversationProps): import("react").JSX.Element;
//# sourceMappingURL=WorkbenchConversation.d.ts.map