/**
 * Mindmap renderer plugin, browser half: contributes a `.mm` preview to the
 * Workbench registry. The package is independent of the kernel: it declares its
 * contract version as data and reaches the registry through `ctx.documentRenderers`.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Required service: the Workbench document renderer registry. */
export declare const inject: string[];
/**
 * Client plugin body: register the mindmap preview for `.mm` documents.
 * @param ctx - client root context, carrying the declared `documentRenderers` service.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map