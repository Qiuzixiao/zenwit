/**
 * Pure FreeMind `.mm` parsing: bounded, DOCTYPE-rejecting, and independent of
 * React so every security rule has a table-driven unit test.
 * @module @deepseek-ai/dsh-client-renderer-mindmap/mindmap
 */
/** One parsed mindmap node: whitelisted attributes plus flattened text. */
export interface MindmapNode {
    /** Display text: flattened `richcontent` text when present, otherwise `TEXT`. */
    readonly text: string;
    readonly position: string | undefined;
    readonly style: string | undefined;
    readonly folded: boolean;
    readonly children: readonly MindmapNode[];
}
/** Hard bounds on parse cost and rendered size. */
export interface MindmapLimits {
    readonly maxNodes: number;
    readonly maxDepth: number;
    readonly maxCharacters: number;
}
/** Defaults matching the renderer contribution's declared 4 MiB budget. */
export declare const MINDMAP_LIMITS: MindmapLimits;
/** Why a document is not a renderable mindmap. */
export type MindmapFailure = 'empty' | 'doctype' | 'too-large' | 'malformed' | 'shape' | 'nodes' | 'depth';
/** Parse outcome: the root node, or the reason the document was refused. */
export type MindmapParseResult = {
    readonly ok: true;
    readonly root: MindmapNode;
} | {
    readonly ok: false;
    readonly reason: MindmapFailure;
};
/**
 * Parse a FreeMind document into a bounded node tree.
 * @param xml - the complete document text.
 * @param limits - hard node, depth and character bounds.
 * @returns the root node, or the refusal reason.
 */
export declare function parseMindmap(xml: string, limits?: MindmapLimits): MindmapParseResult;
//# sourceMappingURL=mindmap.d.ts.map