/** Read-only mindmap view: renders the parsed node tree as React elements. */
import type { ReactNode } from 'react';
import type { PreviewViewProps } from '@deepseek-ai/dsh-client-ui-workbench/preview';
/**
 * Render a `.mm` draft as a mindmap.
 * @param props - the preview props; only `source` and `t` are read.
 * @returns the mindmap tree, or a refusal notice.
 */
export declare function MindmapView({ source, t }: PreviewViewProps): ReactNode;
//# sourceMappingURL=MindmapView.d.ts.map