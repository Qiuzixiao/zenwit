/**
 * Browser-safe and Node-safe media-type knowledge shared by the Workbench
 * preview registry and Host file services: one filename-extension table, one
 * unambiguous byte-signature detector, and an explicit probe that reports
 * agreement between the two sources.
 * @module @deepseek-ai/dsh-util-media-type
 */
/** Canonical MIME type declared by each known filename extension, keyed without its dot. */
export declare const MEDIA_TYPE_BY_EXTENSION: Readonly<Record<string, string>>;
/**
 * Resolve the media type a filename declares through its final extension.
 * @param path - a POSIX or Windows path, with or without directories.
 * @returns the declared MIME type, or `undefined` when the extension is absent, empty, or not in the table.
 */
export declare function extensionForPath(path: string): string | undefined;
/**
 * Resolve the media type a filename declares through its final extension.
 * @param path - a POSIX or Windows path, with or without directories.
 * @returns the declared MIME type, or `undefined` when the extension is absent, empty, or not in the table.
 */
export declare function mediaTypeForPath(path: string): string | undefined;
/**
 * Identify a media type from the leading bytes of a file. Only signatures with
 * one unambiguous type are recognized; short buffers simply match nothing.
 * @param data - the file's leading bytes, typically its first few kilobytes.
 * @returns the detected MIME type, or `undefined` for unrecognized bytes.
 */
export declare function sniffMediaType(data: Uint8Array): string | undefined;
/**
 * Resolve the image MIME type for a path, guaranteeing a usable Blob type.
 * @param path - the file path.
 * @returns the declared media type, or `application/octet-stream` when the extension is unknown.
 */
export declare function imageMimeForPath(path: string): string;
/**
 * Whether a known media type is text that can be read and edited as UTF-8.
 * @param mediaType - a resolved MIME type.
 * @returns whether the type is textual. An unknown type is the caller's policy, not this package's.
 */
export declare function isTextMediaType(mediaType: string): boolean;
/** What a filename and its leading bytes each claim about one file's media type. */
export interface MediaTypeProbe {
    /** Media type declared by the final extension, or `undefined` when absent or unknown. */
    readonly declared: string | undefined;
    /** Media type detected from the leading bytes, or `undefined` when unrecognized or unsupplied. */
    readonly detected: string | undefined;
    /** The authoritative type: detected bytes when available, otherwise the declared extension. */
    readonly mediaType: string | undefined;
    /** Whether a known declared type and a known detected type disagree. */
    readonly mismatch: boolean;
}
/**
 * Resolve a file's media type from its name and, when available, its leading bytes.
 * @param path - the file's POSIX or Windows path.
 * @param data - optional leading bytes; omit when only the extension is known.
 * @returns the declared, detected, and resolved types plus whether two known sources disagree.
 */
export declare function probeMediaType(path: string, data?: Uint8Array): MediaTypeProbe;
//# sourceMappingURL=index.d.ts.map